--  @C:\Work\Pentomino\pentomoni
delete from steen_definitie;
insert into steen_definitie values(1,1, 0,0,  0,1,  0,2,  1,2,  2,2, null, null, null);
insert into steen_definitie values(1,2, 0,2,  1,2,  2,2,  2,1,  2,0, null, null, null);
insert into steen_definitie values(1,3, 0,0,  0,1,  0,2,  1,0,  2,0, null, null, null);
insert into steen_definitie values(1,4, 0,0,  1,0,  2,0,  2,1,  2,2, null, null, null);

insert into steen_definitie values(2,1, 0,0,  0,1,  1,1,  2,1,  3,1, null, null, null);
insert into steen_definitie values(2,2, 0,1,  1,1,  2,1,  3,1,  3,0, null, null, null);
insert into steen_definitie values(2,3, 0,0,  0,1,  1,0,  2,0,  3,0, null, null, null);
insert into steen_definitie values(2,4, 0,0,  1,0,  2,0,  3,0,  3,1, null, null, null);
insert into steen_definitie values(2,5, 0,0,  0,1,  0,2,  0,3,  1,3, null, null, null);
insert into steen_definitie values(2,6, 0,3,  1,0,  1,1,  1,2,  1,3, null, null, null);
insert into steen_definitie values(2,7, 0,0,  0,1,  0,2,  0,3,  1,0, null, null, null);
insert into steen_definitie values(2,8, 0,0,  1,0,  1,1,  1,2,  1,3, null, null, null);

insert into steen_definitie values(3,1, 0,0,  1,0,  0,1,  1,1, null,null, null, null, null);

insert into steen_definitie values(4,1, 0,0,  1,0,  2,0,  3,0, null,null, null, null, null);
insert into steen_definitie values(4,2, 0,0,  0,1,  0,2,  0,3, null,null, null, null, null);

insert into steen_definitie values(5,1, 1,0,  0,1,  1,1,  2,1,  1,2, null, null, null);

insert into steen_definitie values(6,1, 0,0,  1,0,  2,0,  0,1,  2,1, null, null, null);
insert into steen_definitie values(6,2, 0,0,  0,1,  1,1,  2,1,  2,0, null, null, null);
insert into steen_definitie values(6,3, 0,0,  1,0,  1,1,  1,2,  0,2, null, null, null);
insert into steen_definitie values(6,4, 0,0,  0,1,  0,2,  1,0,  1,2, null, null, null);

insert into steen_definitie values(7,1, 1,0,  2,0,  1,1,  0,1,  0,2, null, null, null);
insert into steen_definitie values(7,2, 0,0,  1,0,  1,1,  2,1,  2,2, null, null, null);
insert into steen_definitie values(7,3, 0,0,  0,1,  1,1,  1,2,  2,2, null, null, null);
insert into steen_definitie values(7,4, 0,2,  1,1,  1,2,  2,0,  2,1, null, null, null);


insert into steen_definitie values(8,1, 0,0,  0,1,  1,0, null,null, null,null, null, null, null);
insert into steen_definitie values(8,2, 0,0,  1,0,  1,1, null,null, null,null, null, null, null);
insert into steen_definitie values(8,3, 0,0,  0,1,  1,1, null,null, null,null, null, null, null);
insert into steen_definitie values(8,4, 0,1,  1,0,  1,1, null,null, null,null, null, null, null);


insert into steen_definitie values(9,1, 0,0,  0,1,  1,0,  1,1,  2,0, null, null, null);
insert into steen_definitie values(9,2, 0,0,  0,1,  1,0,  1,1,  2,1, null, null, null);
insert into steen_definitie values(9,3, 0,0,  1,0,  2,0,  1,1,  2,1, null, null, null);
insert into steen_definitie values(9,4, 0,1,  1,0,  2,0,  1,1,  2,1, null, null, null);
insert into steen_definitie values(9,5, 0,0,  0,1,  1,0,  1,1,  0,2, null, null, null);
insert into steen_definitie values(9,6, 0,0,  0,1,  1,0,  1,1,  1,2, null, null, null);
insert into steen_definitie values(9,7, 0,0,  0,1,  1,1,  0,2,  1,2, null, null, null);
insert into steen_definitie values(9,8, 1,0,  0,1,  1,1,  0,2,  1,2, null, null, null);

insert into steen_definitie values(10,1, 0,0, 0,1,  0,2,  0,3,  1,2, null, null, null);
insert into steen_definitie values(10,2, 0,2, 1,0,  1,1,  1,2,  1,3, null, null, null);
insert into steen_definitie values(10,3, 0,0, 0,1,  0,2,  0,3,  1,1, null, null, null);
insert into steen_definitie values(10,4, 0,1, 1,0,  1,1,  1,2,  1,3, null, null, null);
insert into steen_definitie values(10,5, 0,0, 1,0,  2,0,  3,0,  1,1, null, null, null);
insert into steen_definitie values(10,6, 0,0, 1,0,  2,0,  3,0,  2,1, null, null, null);
insert into steen_definitie values(10,7, 1,0, 0,1,  1,1,  2,1,  3,1, null, null, null);
insert into steen_definitie values(10,8, 2,0, 0,1,  1,1,  2,1,  3,1, null, null, null);

insert into steen_definitie values(11,1, 0,0, 0,1,  0,2,  1,0, null,null, null, null, null);
insert into steen_definitie values(11,2, 0,0, 0,1,  0,2,  1,2, null,null, null, null, null);
insert into steen_definitie values(11,3, 0,0, 1,0,  1,1,  1,2, null,null, null, null, null);
insert into steen_definitie values(11,4, 0,2, 1,0,  1,1,  1,2, null,null, null, null, null);
insert into steen_definitie values(11,5, 0,0, 1,0,  2,0,  0,1, null,null, null, null, null);
insert into steen_definitie values(11,6, 0,0, 1,0,  2,0,  2,1, null,null, null, null, null);
insert into steen_definitie values(11,7, 0,0, 0,1,  1,1,  2,1, null,null, null, null, null);
insert into steen_definitie values(11,8, 2,0, 0,1,  1,1,  2,1, null,null, null, null, null);

insert into steen_definitie values(12,1, 0,1, 0,2,  0,3,  1,0,  1,1, null, null, null);
insert into steen_definitie values(12,2, 0,0, 0,1,  1,1,  1,2,  1,3, null, null, null);
insert into steen_definitie values(12,3, 0,0, 0,1,  0,2,  1,2,  1,3, null, null, null);
insert into steen_definitie values(12,4, 0,2, 0,3,  1,0,  1,1,  1,2, null, null, null);
insert into steen_definitie values(12,5, 1,0, 2,0,  3,0,  0,1,  1,1, null, null, null);
insert into steen_definitie values(12,6, 0,0, 1,0,  1,1,  2,1,  3,1, null, null, null);
insert into steen_definitie values(12,7, 0,0, 1,0,  2,0,  2,1,  3,1, null, null, null);
insert into steen_definitie values(12,8, 2,0, 3,0,  0,1,  1,1,  2,1, null, null, null);

commit;

